import React from 'react';
import {random, useCurrentFrame, useVideoConfig} from 'remotion';
import {Toon} from './toon';

const PASTELS = ['#ff6b9d', '#ffd166', '#06d6a0', '#74c0fc', '#b197fc', '#ff9f43'];

/** Cincin bar equalizer di lantai, bergerak mengikuti spektrum audio */
export const EqualizerRing: React.FC<{bars: number[]}> = ({bars}) => {
  const n = bars.length;
  return (
    <group>
      {bars.map((v, i) => {
        const a = (i / n) * Math.PI * 2;
        const h = 0.15 + v * 2.6;
        return (
          <Toon
            key={i}
            color={PASTELS[i % PASTELS.length]}
            position={[Math.cos(a) * 3.6, h / 2, Math.sin(a) * 3.6]}
            rotation={[0, -a, 0]}
            scale={[0.28, h, 0.28]}
            outline={1.12}
          >
            <boxGeometry args={[1, 1, 1]} />
          </Toon>
        );
      })}
    </group>
  );
};

/** Bentuk-bentuk toon melayang di latar */
export const FloatingShapes: React.FC<{bass: number}> = ({bass}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  return (
    <group>
      {new Array(16).fill(0).map((_, i) => {
        const ang = random(`a${i}`) * Math.PI * 2;
        const rad = 6 + random(`r${i}`) * 5;
        const baseY = 1 + random(`y${i}`) * 6;
        const size = 0.35 + random(`s${i}`) * 0.5;
        const kind = i % 4;
        const pos: [number, number, number] = [
          Math.cos(ang) * rad,
          baseY + Math.sin(t * 0.9 + i) * 0.35,
          Math.sin(ang) * rad - 2,
        ];
        const rot: [number, number, number] = [t * (0.3 + (i % 3) * 0.2), t * 0.4, 0];
        const s = size * (1 + bass * 0.25);
        return (
          <Toon key={i} color={PASTELS[i % PASTELS.length]} position={pos} rotation={rot} scale={s}>
            {kind === 0 ? <icosahedronGeometry args={[1, 0]} /> : null}
            {kind === 1 ? <torusGeometry args={[1, 0.38, 14, 28]} /> : null}
            {kind === 2 ? <octahedronGeometry args={[1.1, 0]} /> : null}
            {kind === 3 ? <coneGeometry args={[0.9, 1.6, 6]} /> : null}
          </Toon>
        );
      })}
    </group>
  );
};

/** Lantai + awan */
export const Ground: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  return (
    <group>
      <Toon color="#8ce99a" position={[0, -0.3, 0]} scale={[1, 0.3, 1]} outline={1.02}>
        <cylinderGeometry args={[5.5, 5.8, 1, 48]} />
      </Toon>
      {[0, 1, 2].map((i) => (
        <group key={i} position={[-9 + i * 9 + Math.sin(t * 0.2 + i) * 1.2, 7 + (i % 2), -9]}>
          <Toon color="#ffffff" scale={[1.6, 1, 1]} outline={1.05}>
            <sphereGeometry args={[1, 20, 20]} />
          </Toon>
          <Toon color="#ffffff" position={[1.3, -0.2, 0]} scale={[1.1, 0.8, 0.9]} outline={1.05}>
            <sphereGeometry args={[1, 20, 20]} />
          </Toon>
          <Toon color="#ffffff" position={[-1.4, -0.25, 0]} scale={[1.0, 0.7, 0.9]} outline={1.05}>
            <sphereGeometry args={[1, 20, 20]} />
          </Toon>
        </group>
      ))}
    </group>
  );
};
