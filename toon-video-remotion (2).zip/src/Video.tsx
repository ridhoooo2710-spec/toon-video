import React, {useEffect, useState} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  interpolate,
  interpolateColors,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  delayRender,
  continueRender,
} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {Mascot} from './Mascot';
import {EqualizerRing, FloatingShapes, Ground} from './Scene3D';
import {useAudioReactive} from './audio';

/** Ganti "adegan" (sudut kamera + warna latar) tiap SCENE_SEC detik */
const SCENE_SEC = 12;

const SHOTS = [
  {pos: [0, 3.6, 11.5], look: [0, 2.4, 0], top: '#9bdcff', bottom: '#fff1c9'},
  {pos: [-5.5, 3.2, 8.5], look: [0, 2.6, 0], top: '#ffc2e2', bottom: '#fff0f6'},
  {pos: [0, 4.4, 6.2], look: [0, 3.1, 0], top: '#b8f2c9', bottom: '#fdffd1'},
  {pos: [5.5, 2.8, 9], look: [0, 2.4, 0], top: '#c9b8ff', bottom: '#e0f4ff'},
  {pos: [0, 1.8, 8.2], look: [0, 3.0, 0], top: '#ffd7a8', bottom: '#fff3df'},
] as const;

const CameraRig: React.FC<{pos: number[]; look: number[]}> = ({pos, look}) => {
  const camera = useThree((s) => s.camera);
  camera.position.set(pos[0], pos[1], pos[2]);
  camera.lookAt(look[0], look[1], look[2]);
  return null;
};

type Caption = {start: number; end: number; text: string};

const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const [caps, setCaps] = useState<Caption[]>([]);
  const [handle] = useState(() => delayRender('captions'));

  useEffect(() => {
    fetch(staticFile('captions.json'))
      .then((r) => r.json())
      .then(setCaps)
      .catch(() => setCaps([]))
      .finally(() => continueRender(handle));
  }, [handle]);

  const t = frame / fps;
  const active = caps.find((c) => t >= c.start && t < c.end);
  if (!active) return null;

  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 70}}>
      <div
        style={{
          maxWidth: 1500,
          padding: '18px 36px',
          borderRadius: 32,
          background: 'rgba(27,16,48,0.82)',
          color: '#fff',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif',
          fontWeight: 800,
          fontSize: 54,
          lineHeight: 1.25,
          textAlign: 'center',
          border: '5px solid #ffd166',
        }}
      >
        {active.text}
      </div>
    </AbsoluteFill>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height, durationInFrames} = useVideoConfig();
  const {bars, voice, bass} = useAudioReactive();

  const sceneFrames = SCENE_SEC * fps;
  const idx = Math.floor(frame / sceneFrames);
  const cur = SHOTS[idx % SHOTS.length];
  const prev = SHOTS[(idx + SHOTS.length - 1) % SHOTS.length];
  const local = frame - idx * sceneFrames;

  // Transisi halus 1.2 detik antar adegan (adegan pertama tanpa transisi)
  const blend =
    idx === 0
      ? 1
      : interpolate(local, [0, 1.2 * fps], [0, 1], {
          extrapolateRight: 'clamp',
          easing: Easing.inOut(Easing.cubic),
        });
  const mix = (a: readonly number[], b: readonly number[]) => a.map((v, i) => v + (b[i] - v) * blend);

  // Dolly pelan (zoom in) sepanjang adegan
  const drift = interpolate(local, [0, sceneFrames], [1.0, 0.92]);
  const basePos = mix(prev.pos, cur.pos);
  const camPos = [basePos[0] * drift, basePos[1], basePos[2] * drift];
  const camLook = mix(prev.look, cur.look);

  const top = interpolateColors(blend, [0, 1], [prev.top, cur.top]);
  const bottom = interpolateColors(blend, [0, 1], [prev.bottom, cur.bottom]);

  const intro = interpolate(frame, [0, 20], [0, 1], {extrapolateRight: 'clamp'});
  const outro = interpolate(frame, [durationInFrames - 20, durationInFrames], [1, 0], {
    extrapolateLeft: 'clamp',
  });

  return (
    <AbsoluteFill style={{background: `linear-gradient(${top}, ${bottom})`, opacity: Math.min(intro, outro)}}>
      <Audio src={staticFile('audio.mp3')} />

      <ThreeCanvas width={width} height={height} camera={{fov: 42, near: 0.1, far: 100, position: [0, 3.6, 11.5]}}>
        <CameraRig pos={camPos} look={camLook} />
        <ambientLight intensity={0.9} />
        <directionalLight position={[6, 10, 8]} intensity={2.2} />
        <Ground />
        <EqualizerRing bars={bars} />
        <FloatingShapes bass={bass} />
        <Mascot voice={voice} bass={bass} />
      </ThreeCanvas>

      <Captions />
    </AbsoluteFill>
  );
};
