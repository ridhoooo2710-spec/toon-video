import React, {useMemo} from 'react';
import * as THREE from 'three';

/** Gradient 3 tingkat -> efek cel-shading ala kartun */
export const useToonGradient = () =>
  useMemo(() => {
    const tex = new THREE.DataTexture(new Uint8Array([90, 170, 255]), 3, 1, THREE.RedFormat);
    tex.minFilter = THREE.NearestFilter;
    tex.magFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.needsUpdate = true;
    return tex;
  }, []);

type ToonProps = {
  color: string;
  position?: [number, number, number];
  rotation?: [number, number, number];
  scale?: [number, number, number] | number;
  outline?: number; // skala outline, 0 = tanpa outline
  children: React.ReactNode; // <sphereGeometry /> dst.
};

/** Mesh toon + outline gelap (teknik inverted hull) */
export const Toon: React.FC<ToonProps> = ({
  color,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = 1,
  outline = 1.07,
  children,
}) => {
  const gradient = useToonGradient();
  return (
    <group position={position} rotation={rotation} scale={scale as any}>
      <mesh>
        {children}
        <meshToonMaterial color={color} gradientMap={gradient} />
      </mesh>
      {outline > 0 ? (
        <mesh scale={outline}>
          {children}
          <meshBasicMaterial color="#1b1030" side={THREE.BackSide} />
        </mesh>
      ) : null}
    </group>
  );
};
