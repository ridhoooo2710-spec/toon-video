import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {Toon} from './toon';

type Props = {voice: number; bass: number};

export const Mascot: React.FC<Props> = ({voice, bass}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  const blinkPhase = (t % 3.2) / 0.16; // berkedip tiap ~3.2 detik
  const blink = blinkPhase < 1 ? 1 - Math.sin(blinkPhase * Math.PI) * 0.92 : 1;

  const bob = Math.sin(t * 2.2) * 0.08 + voice * 0.12;
  const squash = 1 + voice * 0.05 - bass * 0.03;
  const mouthOpen = 0.12 + voice * 0.95;
  const armSwing = Math.sin(t * 2.6) * 0.35 + voice * 0.9;
  const headTilt = Math.sin(t * 1.3) * 0.08;

  return (
    <group position={[0, bob, 0]} scale={[1 / squash, squash, 1 / squash]}>
      {/* Kaki */}
      <Toon color="#ff8a5c" position={[-0.55, 0.12, 0.25]} scale={[0.55, 0.28, 0.75]}>
        <sphereGeometry args={[1, 24, 24]} />
      </Toon>
      <Toon color="#ff8a5c" position={[0.55, 0.12, 0.25]} scale={[0.55, 0.28, 0.75]}>
        <sphereGeometry args={[1, 24, 24]} />
      </Toon>

      {/* Badan + perut */}
      <Toon color="#4cc9f0" position={[0, 1.15, 0]} scale={[1.0, 1.1, 0.95]}>
        <sphereGeometry args={[1, 32, 32]} />
      </Toon>
      <Toon color="#caf0f8" position={[0, 1.05, 0.72]} scale={[0.62, 0.7, 0.3]} outline={0}>
        <sphereGeometry args={[1, 24, 24]} />
      </Toon>

      {/* Lengan */}
      <group position={[-1.0, 1.55, 0]} rotation={[0, 0, 0.5 + armSwing]}>
        <Toon color="#4cc9f0" position={[-0.05, -0.45, 0]} scale={[0.3, 0.6, 0.3]}>
          <sphereGeometry args={[1, 20, 20]} />
        </Toon>
      </group>
      <group position={[1.0, 1.55, 0]} rotation={[0, 0, -0.5 - armSwing * 0.8]}>
        <Toon color="#4cc9f0" position={[0.05, -0.45, 0]} scale={[0.3, 0.6, 0.3]}>
          <sphereGeometry args={[1, 20, 20]} />
        </Toon>
      </group>

      {/* Kepala */}
      <group position={[0, 3.0, 0]} rotation={[0, 0, headTilt]}>
        <Toon color="#ffd166">
          <sphereGeometry args={[1.25, 40, 40]} />
        </Toon>

        {/* Antena */}
        <Toon color="#1b1030" position={[0, 1.4, 0]} scale={[0.06, 0.35, 0.06]} outline={0}>
          <cylinderGeometry args={[1, 1, 1, 8]} />
        </Toon>
        <Toon color="#ef476f" position={[0, 1.8 + bass * 0.12, 0]} scale={0.22 + bass * 0.08}>
          <sphereGeometry args={[1, 20, 20]} />
        </Toon>

        {/* Telinga */}
        <Toon color="#ffb703" position={[-1.22, 0.1, 0]} scale={[0.28, 0.4, 0.28]}>
          <sphereGeometry args={[1, 20, 20]} />
        </Toon>
        <Toon color="#ffb703" position={[1.22, 0.1, 0]} scale={[0.28, 0.4, 0.28]}>
          <sphereGeometry args={[1, 20, 20]} />
        </Toon>

        {/* Mata */}
        {[-0.48, 0.48].map((x) => (
          <group key={x} position={[x, 0.3, 1.05]} scale={[1, blink, 1]}>
            <Toon color="#ffffff" scale={[0.3, 0.38, 0.2]} outline={1.1}>
              <sphereGeometry args={[1, 24, 24]} />
            </Toon>
            <Toon color="#1b1030" position={[0, 0, 0.17]} scale={[0.16, 0.2, 0.1]} outline={0}>
              <sphereGeometry args={[1, 16, 16]} />
            </Toon>
            <Toon color="#ffffff" position={[0.05, 0.08, 0.26]} scale={0.05} outline={0}>
              <sphereGeometry args={[1, 8, 8]} />
            </Toon>
          </group>
        ))}

        {/* Pipi */}
        <Toon color="#ff8fa3" position={[-0.85, -0.25, 0.85]} scale={[0.2, 0.12, 0.1]} outline={0}>
          <sphereGeometry args={[1, 16, 16]} />
        </Toon>
        <Toon color="#ff8fa3" position={[0.85, -0.25, 0.85]} scale={[0.2, 0.12, 0.1]} outline={0}>
          <sphereGeometry args={[1, 16, 16]} />
        </Toon>

        {/* Mulut: membuka mengikuti volume suara */}
        <Toon color="#7a1f3d" position={[0, -0.42, 1.12]} scale={[0.3, mouthOpen * 0.35, 0.12]} outline={1.12}>
          <sphereGeometry args={[1, 24, 24]} />
        </Toon>
      </group>
    </group>
  );
};
