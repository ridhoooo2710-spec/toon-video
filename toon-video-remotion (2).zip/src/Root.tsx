import React from 'react';
import {Composition, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {Video} from './Video';

export const FPS = 30;

export const Root: React.FC = () => {
  return (
    <Composition
      id="ToonVideo"
      component={Video}
      width={1920}
      height={1080}
      fps={FPS}
      durationInFrames={5706} // cadangan (190.2 dtk); nilai asli dihitung di bawah
      calculateMetadata={async () => {
        // Durasi video = durasi audio, otomatis
        const seconds = await getAudioDurationInSeconds(staticFile('audio.mp3'));
        return {durationInFrames: Math.ceil(seconds * FPS)};
      }}
    />
  );
};
