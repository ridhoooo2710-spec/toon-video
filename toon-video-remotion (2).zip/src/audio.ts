import {staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {useAudioData, visualizeAudio} from '@remotion/media-utils';

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));

/** Spektrum audio per frame + amplitudo suara (mulut) dan bass (denyut) */
export const useAudioReactive = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const audioData = useAudioData(staticFile('audio.mp3'));

  if (!audioData) {
    return {bars: new Array(32).fill(0) as number[], voice: 0, bass: 0};
  }

  const sample = (f: number) =>
    visualizeAudio({fps, frame: Math.max(0, f), audioData, numberOfSamples: 64});

  const now = sample(frame);
  const spectra = [now, sample(frame - 1), sample(frame - 2)]; // rata-rata 3 frame -> mulut halus
  const avg = (arr: number[], from: number, to: number) =>
    arr.slice(from, to).reduce((a, b) => a + b, 0) / (to - from);

  const voice = clamp((spectra.reduce((s, sp) => s + avg(sp, 1, 12), 0) / spectra.length) * 6);
  const bass = clamp(avg(now, 0, 4) * 3);
  const bars = now.slice(0, 32).map((v) => clamp(Math.pow(v, 0.6) * 1.6));

  return {bars, voice, bass};
};
