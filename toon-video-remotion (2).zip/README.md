# Video 3D Toon (Remotion)

Durasi video otomatis = durasi audio (190,2 dtk, 1920x1080, 30 fps).

## Cara pakai
1. `npm install`
2. `npm run dev`  -> pratinjau di Remotion Studio
3. `npm run render` -> hasil di `out/video.mp4`
   (tes cepat: `npm run render:preview`)

## Kustomisasi
- Audio: ganti `public/audio.mp3` (durasi menyesuaikan otomatis)
- Teks/subtitle: isi `public/captions.json` -> [{"start":0,"end":4,"text":"..."}]
- Warna & sudut kamera: array SHOTS di `src/Video.tsx` (ganti adegan tiap 12 detik)
- Karakter: `src/Mascot.tsx` (mulut bergerak mengikuti volume suara)

## Render dari HP (GitHub Actions)
1. Upload semua isi proyek ke repo GitHub (branch `main`).
2. Tab Actions -> "Render video" -> Run workflow (atau otomatis saat push).
3. Setelah selesai, buka run-nya -> Artifacts -> download `video`.
